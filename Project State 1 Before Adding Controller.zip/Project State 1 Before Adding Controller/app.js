const express = require('express');
const bodyParser = require('body-parser')
const path = require('path');


const app = express();
app.set('view engine', 'ejs');
app.set('views', 'views'); //default: process.cwd() + '/views'

const adminData = require('./routes/admin');
const shopRoutes = require('./routes/shop');

//bodyParse use to convert raw streams data (in bits and not readable) to readable text object in the body
app.use(bodyParser.urlencoded({extended: false}))
app.use(express.static(path.join(__dirname, 'public')))

//first parameter is for filtering all routes start with /admin
app.use('/admin', adminData.routes);
app.use(shopRoutes);


//if no route execute => error
app.use((req,res,next) => {
    // res.status(404).sendFile("views/404.html", {root: '.'})
    res.status(404).render('404', {pageTitle : 'Page Not Found'});
})

app.listen(3000)
// app.listen includes const server = http.createServer(app) and server.listen(3000)

