const path = require('path')
const rootDir = require('../util/path')

const express = require('express');
const adminData = require('./admin');
const route = express.Router();

//If two middleware with same route, must have next() end of callback to allow the request to continue to the next middleware
route.get('/', (req, res, next) => {
    const products = adminData.products;
    // res.setHeader()
    // res.sendFile('/views/shop.html', { root: '.' });
    // res.sendFile(path.join(rootDir, '..', 'views', 'shop.html'));
    // console.log(adminData.products); 
    // res.sendFile(path.join(__dirname, '..', 'views', 'shop.html')); 
    res.render('shop', {
        prods: products,
        pageTitle: "Shop",
        path: '/',
        hasProducts: products.length >0,
        activeShop: true,
        productCSS: true
    })
});

module.exports = route;